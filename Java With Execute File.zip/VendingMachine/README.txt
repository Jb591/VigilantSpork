To run this file go to terminal and cd to the file and once there type the command
ls into the terminal and you should see all the java files, a makefile and
this README file.

Once in that file type the following commands :
  make
  make run

it will run the code and proceed as should
