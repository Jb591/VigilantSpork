public class Product 
{
	public String name;
	public double price;
	public int stock;
	public String code;
	public Product(String x, double y, int z, String c)
	{
		name = x;
		price = y;
		stock = z;
		code = c;
	}
}
