public class Bank 
{
	public int num;
	public double value;
	public String name;
	public Bank(int x, double y, String z)
	{
		num = x;
		value = y;
		name = z;
	}
}
