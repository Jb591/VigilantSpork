public class Choice 
{
	public double total;
	public String choice;
	public int index;
	public int round;
	public double collected;
	public double gTotal;
	public Choice ()
	{
		total = 0;
		choice = null;
		index = 0;
		collected = 0;
		round = 0;
		gTotal = 0;
	}
}
