To run this file go to terminal and cd to the file and once there type the command
ls into the terminal and you should see all the java files, a makefile and
this README file.

Once in that file type the following commands in terminal:
  make
  make run

Once you hit make, You will be prompted to enter the number of numUsers
This number can be infinitely large. Once entered a GUI will appear with
that many users
