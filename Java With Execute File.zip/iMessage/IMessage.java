public interface IMessage 
{
	void chat(String input);
}
